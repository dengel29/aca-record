import { Component, OnInit, Input } from '@angular/core';
import { SubjectCreatorService } from '../services/subject-creator.service';
import { Player } from '../models/player.model';



@Component({
  selector: 'app-grades-box',
  templateUrl: './grades-box.component.html',
  styleUrls: ['./grades-box.component.scss']
})
export class GradesBoxComponent implements OnInit {
  scService: SubjectCreatorService;
  currentStudent;
  subjects = [];

  constructor(scService: SubjectCreatorService) {
    this.scService = scService;
    this.scService.toggle$.subscribe(id => {
      this.currentStudent = this.scService.findStudentById(id);
      this.subjects = this.scService.findCoursesByStudent(id);
    });
  }

  ngOnInit() {
    this.scService.launch();
  }

  onSubmit(form) {
    this.scService.makeNewSubject(form);
    document.getElementById('subject').focus();
  }
}
