import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import {SubjectCreatorService} from '../services/subject-creator.service';
import {Player} from '../models/player.model';

@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.scss']
})
export class PlayerListComponent implements OnInit {
  // @Input() vertical: boolean;
  scService: SubjectCreatorService;
  players: Player[];
  @ViewChild('group', {static: true}) itemValue;

  constructor(scService: SubjectCreatorService) {
    this.scService = scService;
    this.players = this.scService.allPlayers();
  }

  ngOnInit() {}



  selectPlayer() {
    const el = document.getElementById(this.itemValue.value);
    el.classList.toggle('selected');

    // tslint:disable-next-line: radix
    this.scService.toggleId(parseInt(this.itemValue.value));
  }

}
