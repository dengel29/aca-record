export class Player {
  constructor(public id: number, public name: string, public courses: [], public okay: boolean) {}
}
