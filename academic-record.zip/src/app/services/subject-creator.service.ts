import {Player} from '../models/player.model';
import { Subject } from 'rxjs';

export class SubjectCreatorService {
  currentStudent;
  currentSubjects;
  players: Player[] = [
    new Player(25, 'Bobby Burger', [], true),
    new Player(1, 'Tina Fay', [], false),
    new Player(2, 'Andy Bourdain', [], false),
    new Player(5, 'Bobby Flay', [], false),
    new Player(3, 'Hungry Thomas', [], true),
    new Player(4, 'Jenna Marbles', [], false),
    new Player(6, 'Belle Delphine', [], false),
    new Player(7, 'Jay Jay', [], false),
  ];

  private id = new Subject();
  toggle$ = this.id.asObservable();

  launch() {
    this.id.next(this.players[0].id)
  }

  toggleId(selectedId) {
    this.id.next(selectedId);
  }

  clearSubjects() {
    this.currentSubjects = [];
    return [];
  }

  deleteSubject(id) {
    const index = this.currentStudent.courses.findIndex( c => {
        return c.id === id;
    });
    this.currentStudent.courses.splice(index, 1);
  }

  makeNewSubject(formData) {
    const subject = formData.value;
    subject.studentId = this.currentStudent.id;
    subject.id = this.currentStudent.courses.length;
    this.currentStudent.courses.push(subject);
  }

  findCoursesByStudent(id) {
    this.currentStudent = this.findStudentById(id);
    this.currentSubjects = this.currentStudent.courses;
    return this.currentSubjects;
  }

  allPlayers() {
    return this.players;
  }

  findStudentById(id) {
    const result = this.players.find(player => {
      return player.id === id;
    });
    this.currentStudent = result;
    return result;
  }
}
