import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-subject-list',
  templateUrl: './subject-list.component.html',
  styleUrls: ['./subject-list.component.scss']
})
export class SubjectListComponent implements OnInit {
  @Input() subjects: [];
  constructor() { }


  ngOnInit() {}

}
